<?php
  /*
   *  @author   Gopal Joshi
   *  @about    Stripe Payment Gateway integration in PHP
   *  @tutorial http://sgeek.org/integrate-stripe-payment-gateway-using-php-javascript/
   */
?>
<html>
<head>
	<title>Stripe Demo - Sgeek</title>
</head>
<body>
	<div>
		<h2>SSL Certificate ($50)</h2>
		<div>
			<form action="return.php" method="POST">
			  <script
			    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
			    data-key="pk_test_ZAvblirrUl7Vvvbi1F6GJiy3"
			    data-amount="5000"
			    data-locale="us-en"
			    data-name="SSL Certificate (Demo Product)"
			    data-description="SSL Certificate ($50)"
			    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
			    data-locale="auto">
			  </script>
			</form>
		</div>
	</div>
</body>
</html>